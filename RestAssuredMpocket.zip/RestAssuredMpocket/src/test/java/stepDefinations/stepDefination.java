package stepDefinations;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import pageObjects.RestAssureCreat;



public class stepDefination {
		
	@Given("^I execute createEmployee EndPoint$")
	public void createEmployeeData()
	{
		RestAssureCreat.createEmp();
	}
	@And("^I should get success status code")
	public void getEmploye()
	{
		RestAssureCreat.getstatusCodeEmploycr();		
	}
	@Given("^I submit the Get request for User$")
	public void postGetRequest()
	{
		RestAssureCreat.getEmployS();
	}
	
	@Then("^I validate get employee$")
	public void getValid()
	{
		RestAssureCreat.getValidate();
	}
	
	@Given("^I delete the Employee id$")
	public void deleteEmp()
	{
		RestAssureCreat.deletEmp();
	}
	
	@And("^I should get status code$")
	public void statuscodvali()
	{
		RestAssureCreat.getStatusCodeForEmp();
	}
	
	@Then("^I validate delete$")
	public void deletvalid()
	{
		RestAssureCreat.validatDelet();
	}
	
	
}