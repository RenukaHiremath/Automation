package pageObjects;

import java.util.HashMap;

import org.json.simple.JSONObject;

import com.google.gson.JsonObject;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class RestAssureCreat  {

	public static Response resp;
	public static int user_id = 0;
	public static JsonPath jpath;
	public static void createEmp()
	{
		try {

			RestAssured.baseURI ="http://dummy.restapiexample.com/api/v1/create";
			RequestSpecification httpReq = RestAssured.given();

			JSONObject params = new JSONObject();

			params.put("name", "avina");
			params.put("salary", "743");
			params.put("age", "28");
			httpReq.header("Content-Type", "application/json");
			String content = params.toJSONString();
			
			System.out.println(content);

			httpReq.body(content);
			resp = httpReq.post();
			jpath = resp.jsonPath();

		}catch(Exception e)
		{
			System.out.println("failed to create post");
		}
	}
	
		public static void getstatusCodeEmploycr()
	{
		try {
			Thread.sleep(2000);
			String statuss = jpath.getString("status");

			System.out.println("I validate success status  as : "+statuss);

			int statuscode = resp.getStatusCode();
			System.out.println(statuscode+" I validate success code");

			String statusl = resp.getStatusLine();
			System.out.println(statusl);

			String id = jpath.getString("data");
			System.out.println(id+"  recieved id");
			user_id = convStringToMap(id);
		//	user_id = Integer.parseInt(jpath.getString("id"));
			System.out.println(user_id+ " user id created");
			String respcont = resp.body().asString();
			System.out.println(respcont);

		}catch(Exception e)
		{
			System.out.println("failed to get status code empl ");
		}
	}
		
		public static void getStatusCodeForEmp()
		{
			try {
				int statuscode = resp.getStatusCode();
				System.out.println(statuscode+" I validate success code");

				String statusl = resp.getStatusLine();
				System.out.println(statusl);
				

			//	System.out.println(user_id+ " user id from response");
				String respcont = resp.body().asString();
				System.out.println(respcont);

				
			}catch(Exception e)
			{
				System.out.println("failed to get status other meth");
			}
		}
		
		public static int convStringToMap(String in)
		{
			
		//	String stri = in.replaceAll("\\[", "").replaceAll("\\]","");
			String stri = in.replace("[", "").replace("]", "").replace("{", "").replace("}", "");
		
			String vin = stri.trim();
			String[] inp = vin.split(",");
			
			HashMap<String,String> mp = new HashMap<String,String>();
			try {
				for(String inf:inp)
				{
					String inz = inf.trim();
					String col[]=inz.split(":");
					mp.put(col[0], col[1]);
				}
				String cha = mp.get("id");
				int chai = Integer.parseInt(cha);
				return chai;
			}catch(Exception e)
			{
				System.out.println("failed to convert string to map");
				return 0;
			}
		}



	public static void getEmployS()
	{
		try {
			RestAssured.baseURI = "http://dummy.restapiexample.com/api/v1/employee";
			RequestSpecification httpreq = RestAssured.given();

			resp = httpreq.get("/"+user_id);
			jpath = resp.jsonPath();
			
		}catch(Exception e)
		{
			System.out.println("failed getEmployS");
		}
	}
	
	public static void getValidate()
	{
		try {
			String stat = jpath.getString("status");
			System.out.println("I validate get status as: "+stat);
			String stringdat = jpath.getString("data");
			int id = convStringToMap(stringdat);
			System.out.println("Validated response body: "+id);
			
			
		}catch(Exception e)
		{
			System.out.println("Failed getValidate()");
		}
	}

	public static void deletEmp()
	{
		try {
			RestAssured.baseURI ="http://dummy.restapiexample.com/api/v1/delete";
			RequestSpecification httpr = RestAssured.given();
			resp = httpr.delete("/"+user_id);
			jpath = resp.jsonPath();

		}catch(Exception e)
		{
			System.out.println("failed to delet the emp");
		}
	}
	
	public static void validatDelet()
	{
		try {
			String respcont = resp.body().asString();
			System.out.println(respcont);
			System.out.println(jpath.getString("status"));
			System.out.println(jpath.getString("message"));

			
		}catch(Exception e)
		{
			System.out.println("failed to validate");
		}
	}

}
